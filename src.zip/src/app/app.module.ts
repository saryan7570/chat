import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RouterModule } from '@angular/router';
import { ChatService } from './chat.service';
import { ChatModule } from './chat/chat.module';
import { AppService } from './app.service';

@NgModule({
  imports: [
    FormsModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    RouterModule,
    ChatModule,
   
   
  ],
  declarations: [
    AppComponent,
  ],
  providers: [
   
    ChatService,
    AppService,
    

  ],
  bootstrap: [AppComponent],
})
export class AppModule {
}
